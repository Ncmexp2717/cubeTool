evalTcl(interp, "argc_d", HEREDOC(
puts stderr "Error: Wrong arguments.";
exit 3;
)
);
